function onclick_handler() {
	alert("This test has passed.")
	return true
}